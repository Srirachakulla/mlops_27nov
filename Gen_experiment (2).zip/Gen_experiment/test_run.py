# Databricks notebook source
import os
os.environ["SCENARIO"] = "regression"

# COMMAND ----------

import run_experiment
run_experiment.main()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

