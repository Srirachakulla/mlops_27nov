import os, yaml
import pandas as pd
from mlops_core.core import BaseTrainer
from pipelines.pipeline_factory import build_pipeline

class GenericTrainer(BaseTrainer):
    def __init__(self):
        super().__init__()
        scenario = os.environ.get("SCENARIO", "classification")
        with open("config.yaml", "r") as f:
            cfg = yaml.safe_load(f) or {}
        defaults = cfg.get("defaults", {})
        sc = {**defaults, **cfg["scenarios"][scenario]}

        self.cfg = sc
        # set internal fields (BaseTrainer properties are read-only)
        self._problem_type  = sc["task_type"]
        self._feature_table = sc["feature_table"]
        self._label_col     = sc.get("label_col")

        self.algorithm   = sc.get("algorithm", "logreg")
        self._param_grid = sc.get("param_grid", {}) or {}
        self._drop_cols  = list(sc.get("drop_cols", []))

    @property
    def feature_table(self) -> str:
        return self._feature_table

    @property
    def problem_type(self) -> str:
        return self._problem_type

    @property
    def label_col(self) -> str:
        # If None for clustering, fall back to BaseTrainer default only when not clustering
        return self._label_col if self._label_col is not None else super().label_col
 


    def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        drops = self._drop_cols
        return df.drop(columns=[c for c in drops if c in df], errors="ignore").fillna(0)

    def build_pipeline(self):
        return build_pipeline(self.algorithm)

    def param_grid(self):
        return self._param_grid
 