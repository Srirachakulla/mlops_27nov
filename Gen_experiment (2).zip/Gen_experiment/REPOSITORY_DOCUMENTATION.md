# Generic MLOps Trainer - Comprehensive Repository Documentation

**Date:** November 27, 2025  
**Repository:** Gen_experiment  
**Purpose:** A flexible, configuration-driven MLOps framework for training, tracking, and registering machine learning models across multiple problem types (classification, regression, clustering).

---

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Repository Structure](#repository-structure)
3. [Core Components](#core-components)
4. [End-to-End Flow](#end-to-end-flow)
5. [Configuration System](#configuration-system)
6. [Data Flow & Dependencies](#data-flow--dependencies)
7. [Key Features](#key-features)
8. [Monitoring & Tracking](#monitoring--tracking)
9. [Testing Strategy](#testing-strategy)
10. [Usage Examples](#usage-examples)

---

## Architecture Overview

### Design Philosophy
This repository implements a **generic, scenario-based MLOps framework** that:
- Supports multiple ML problem types (classification, regression, clustering)
- Uses a single configuration file (`config.yaml`) to define scenarios
- Abstracts training logic through inheritance (`BaseTrainer`)
- Integrates with Databricks Unity Catalog and MLflow
- Provides comprehensive monitoring through dedicated tables
- Enables Grid Search hyperparameter tuning with full trial tracking

### Technology Stack
- **ML Framework:** scikit-learn
- **Data Platform:** Databricks (PySpark)
- **Experiment Tracking:** MLflow with Unity Catalog
- **Configuration:** YAML-based
- **Testing:** pytest
- **Language:** Python 3.x

---

## Repository Structure

```
Gen_experiment/
│
├── config.yaml                      # Main configuration file (scenarios, defaults, parameters)
├── generic_trainer.py               # Concrete implementation of BaseTrainer
├── run_experiment.py                # Entry point orchestrator
├── test_run.py                      # Databricks notebook for ad-hoc testing
│
├── mlops_core/                      # Core framework package
│   ├── __init__.py                  # Package exports: BaseTrainer, TrainerRunner
│   └── core.py                      # Abstract base classes and orchestration logic
│
├── pipelines/                       # Pipeline construction module
│   ├── __init__.py                  # (empty)
│   └── pipeline_factory.py          # Algorithm-to-pipeline mapping
│
├── adapters/                        # (currently empty - for future data adapters)
│
└── tests/                           # Unit tests
    ├── test_generic_trainer.py      # Tests for GenericTrainer class
    └── test_pipeline_factory.py     # Tests for pipeline factory
```

---

## Core Components

### 1. **config.yaml** - Configuration Hub

**Purpose:** Single source of truth for all ML experiments

**Structure:**
```yaml
defaults:                            # Global defaults applied to all scenarios
  registry_uri: databricks-uc
  monitoring_table: anl_drishti.test_mlops_monitoring.model_runs
  cv_folds: 5
  random_state: 42
  drop_cols: ["PassengerId"]

scenarios:                           # Scenario-specific configurations
  classification:                    # Titanic survival prediction
    feature_table: anl_drishti.test_mlops_features.titanic_fs
    task_type: classification
    label_col: Survived
    algorithm: logreg
    metrics: [accuracy, f1]
    param_grid:
      clf__C: [0.1, 1.0, 10.0]
      clf__penalty: [l2]
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.TitanicGeneric

  regression:                        # Auto MPG prediction
    feature_table: anl_drishti.test_mlops_features.autompg_fs
    task_type: regression
    label_col: mpg
    algorithm: linreg
    metrics: [rmse, mae, r2]
    param_grid: {}
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.autompgregression

  clustering:                        # Iris clustering
    feature_table: anl_drishti.test_mlops_features.iris_fs
    task_type: clustering
    label_col: null
    algorithm: kmeans
    metrics: [silhouette, davies_bouldin]
    param_grid:
      clf__n_clusters: [2, 3, 4, 5, 6, 7, 8, 9, 10]
      clf__n_init: [10, 20]
      clf__random_state: [42]
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.irisClustering
```

**Key Configuration Elements:**
- `feature_table`: Unity Catalog table path containing input features
- `task_type`: ML problem type (classification/regression/clustering)
- `label_col`: Target variable name (null for unsupervised)
- `algorithm`: Short key for ML algorithm (see pipeline_factory.py)
- `param_grid`: GridSearchCV hyperparameter search space
- `metrics`: List of evaluation metrics to compute
- `registry.uc_model_name`: Unity Catalog model registration path

---

### 2. **mlops_core/core.py** - Framework Foundation

#### BaseTrainer (Abstract Class)

**Purpose:** Defines the contract and common functionality for all trainers

**Key Properties (Must Override):**
```python
@property
def feature_table(self) -> str:
    # UC table path to read features from
    
@property
def problem_type(self) -> str:
    # One of: "classification", "regression", "clustering"
    
@property
def label_col(self) -> str:
    # Target column name (default: "label")
```

**Key Methods (Optional Overrides):**
```python
def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
    # Data preprocessing logic (default: identity)
    
def build_pipeline(self) -> sklearn.Pipeline:
    # ML pipeline construction (default: StandardScaler + LogisticRegression)
    
def param_grid(self) -> Dict[str, Any]:
    # GridSearchCV parameter grid (default: empty dict)
    
def metrics(self) -> Dict[str, Callable]:
    # Custom metric functions (default: empty dict)
```

**Core Training Method:**
```python
def train(self, spark_df) -> Tuple[Any, Dict[str, Any], Dict[str, Any]]:
    """
    Main training pipeline:
    1. Convert Spark DataFrame to Pandas
    2. Preprocess data
    3. Split features/labels based on problem_type
    4. Train/test split (stratified for binary classification)
    5. GridSearchCV if param_grid provided
    6. Evaluate metrics
    7. Capture all CV trials in self._grid_trials
    
    Returns: (model, metrics_dict, params_dict)
    """
```

**Important Training Details:**
- **Classification:** Uses stratified split for binary, accuracy/AUC/F1/precision/recall metrics
- **Regression:** Regular split, RMSE/MAE/R2 metrics
- **Clustering:** No train/test split, silhouette/Davies-Bouldin scores
- **GridSearchCV:** Automatically uses appropriate scoring function:
  - Classification: 'roc_auc' (binary) or 'accuracy' (multi-class)
  - Regression: 'r2'
  - Clustering: Custom silhouette scorer
- **Trial Tracking:** All CV results stored in `self._grid_trials` list

---

#### TrainerRunner (Orchestrator Class)

**Purpose:** Manages the complete MLOps lifecycle

**Initialization:**
```python
TrainerRunner(
    trainer_module: str,              # Module name to import trainer from
    trainer_class: str,               # Class name to instantiate
    register_model_name: str,         # UC model registration path
    register_stage: Optional[str],    # Model stage (unused currently)
    allow_stage_transition: bool,     # Stage transition flag (unused)
    trainer: Optional[BaseTrainer],   # Pre-instantiated trainer (alternative to module/class)
    monitoring_table: Optional[str]   # Custom monitoring table path
)
```

**Main Execution Flow:**
```python
def run(self) -> Dict[str, Any]:
    """
    1. Load trainer (via dynamic import or pre-instantiated)
    2. Read feature table from Spark
    3. Validate trainer configuration
    4. Train and register model
    5. Write monitoring rows
    
    Returns: {
        "run_id": str,
        "run_url": str,
        "metrics": Dict[str, float],    # Best holdout metrics
        "params": Dict[str, str],        # Best parameters
        "trials": List[Dict],            # All GridSearch CV trials
        "feature_table": str             # Source feature table
    }
    """
```

**Key Methods:**

1. **`_load_trainer()`**
   - Dynamically imports trainer module and instantiates class
   - Alternative: use pre-provided trainer instance

2. **`_read_feature_table(table_name)`**
   - Reads Unity Catalog table via Spark
   - Returns PySpark DataFrame

3. **`_train_and_register(trainer, spark_df)`**
   - Starts MLflow run
   - Calls `trainer.train()` 
   - Logs params and metrics to MLflow
   - Logs sklearn model with signature and input example
   - Registers model to Unity Catalog
   - Captures all GridSearch trials from `trainer._grid_trials`

4. **`_write_monitoring_rows(result)`**
   - Writes detailed tracking data to monitoring table
   - Creates two types of rows:
     - **Best model row:** Single row with best holdout metrics
     - **CV trial rows:** One row per GridSearch combination
   - Enforces strict schema: `metrics` as MAP<STRING,DOUBLE>, `params` as MAP<STRING,STRING>
   - Adds metadata flags: `__row_type`, `__is_best`, `__feature_table`

---

#### validate_trainer_config(trainer, df)

**Purpose:** Pre-training validation to catch configuration errors early

**Validations:**
1. **Problem Type:** Must be 'classification', 'regression', or 'clustering'
2. **Label Column:** Must exist in DataFrame for supervised tasks
3. **Pipeline Compatibility:** Checks for required methods (predict/fit_predict)
4. **Hyperparameters:** Validates param_grid keys against pipeline parameters
5. **Custom Metrics:** Ensures metrics() returns dict of callables

---

### 3. **generic_trainer.py** - Concrete Implementation

**Purpose:** Scenario-driven trainer that reads config.yaml

**Initialization Logic:**
```python
def __init__(self):
    # 1. Read SCENARIO from environment variable (default: "classification")
    scenario = os.environ.get("SCENARIO", "classification")
    
    # 2. Load config.yaml
    with open("config.yaml", "r") as f:
        cfg = yaml.safe_load(f)
    
    # 3. Merge defaults with scenario-specific config
    defaults = cfg.get("defaults", {})
    sc = {**defaults, **cfg["scenarios"][scenario]}
    
    # 4. Set internal properties from merged config
    self._problem_type = sc["task_type"]
    self._feature_table = sc["feature_table"]
    self._label_col = sc.get("label_col")
    self.algorithm = sc.get("algorithm", "logreg")
    self._param_grid = sc.get("param_grid", {}) or {}
    self._drop_cols = list(sc.get("drop_cols", []))
```

**Method Implementations:**
- **`preprocess(df)`:** Drops columns specified in config, fills NaN with 0
- **`build_pipeline()`:** Delegates to `pipeline_factory.build_pipeline(algorithm)`
- **`param_grid()`:** Returns hyperparameter grid from config

**Design Pattern:** Configuration-based polymorphism - behavior changes based on YAML, not code

---

### 4. **pipelines/pipeline_factory.py** - Algorithm Registry

**Purpose:** Central mapping of algorithm keys to sklearn pipelines

**Algorithm Registry:**
```python
ESTIMATORS = {
    # Classification
    "logreg": LogisticRegression,
    "rf_cls": RandomForestClassifier,
    
    # Regression
    "linreg": LinearRegression,
    "rf_reg": RandomForestRegressor,
    
    # Clustering
    "kmeans": KMeans,
}
```

**Pipeline Construction:**
```python
def build_pipeline(algo_key: str) -> Pipeline:
    """
    Creates Pipeline([
        ("scaler", StandardScaler),
        ("clf", EstimatorClass())
    ])
    
    Note: KMeans uses StandardScaler(with_mean=True)
          Others use StandardScaler(with_mean=False)
    """
```

**Extension Point:** To add new algorithms:
1. Add entry to `ESTIMATORS` dict
2. Update config.yaml scenarios
3. No other code changes needed

---

### 5. **run_experiment.py** - Entry Point

**Purpose:** Validates configuration and orchestrates training

**Execution Flow:**

```python
def main():
    # 1. Read SCENARIO from environment
    scenario = os.environ.get("SCENARIO", "classification")
    
    # 2. Load and merge config
    with open("config.yaml") as f:
        cfg = yaml.safe_load(f)
    sc = {**cfg["defaults"], **cfg["scenarios"][scenario]}
    
    # 3. Validate metrics against allowed set
    ALLOWED_METRICS = {
        "classification": {"accuracy","f1","precision","recall","roc_auc"},
        "regression": {"rmse","mae","r2"},
        "clustering": {"silhouette","davies_bouldin"},
    }
    # Exits if invalid metrics found
    
    # 4. Initialize TrainerRunner with dynamic loading
    runner = TrainerRunner(
        trainer_module="generic_trainer",
        trainer_class="GenericTrainer",
        register_model_name=sc["registry"]["uc_model_name"],
        register_stage=None,
        allow_stage_transition=False
    )
    
    # 5. Execute training pipeline
    result = runner.run()
    
    # 6. Print summary
    print("Scenario:", scenario)
    print("Task Type:", sc["task_type"])
    print("Algorithm:", sc["algorithm"])
    print("MLflow URL:", result["run_url"])
    print("Best Metrics:", result["metrics"])
    print("Best Params:", result["params"])
```

**Error Handling:**
- Validates scenario exists in config
- Validates metrics are appropriate for task type
- Exits with error code on validation failure

---

### 6. **test_run.py** - Databricks Notebook

**Purpose:** Ad-hoc testing interface for Databricks

**Usage:**
```python
# Cell 1: Set scenario
import os
os.environ["SCENARIO"] = "regression"

# Cell 2: Run experiment
import run_experiment
run_experiment.main()
```

**Note:** This is a Databricks notebook format (# COMMAND ---------- separators)

---

## End-to-End Flow

### Complete Execution Sequence

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. INITIALIZATION                                               │
└─────────────────────────────────────────────────────────────────┘
   │
   ├─► Set SCENARIO environment variable (default: "classification")
   ├─► run_experiment.py reads config.yaml
   ├─► Merges defaults with scenario-specific config
   └─► Validates metrics against allowed set

┌─────────────────────────────────────────────────────────────────┐
│ 2. TRAINER SETUP                                                │
└─────────────────────────────────────────────────────────────────┘
   │
   ├─► TrainerRunner.__init__()
   │   └─► Stores trainer_module, trainer_class, register_model_name
   │
   └─► runner.run() called
       └─► _load_trainer() dynamically imports GenericTrainer
           └─► GenericTrainer.__init__()
               ├─► Reads config.yaml again
               ├─► Sets problem_type, feature_table, label_col
               └─► Configures algorithm, param_grid, drop_cols

┌─────────────────────────────────────────────────────────────────┐
│ 3. DATA LOADING                                                 │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► _read_feature_table(trainer.feature_table)
       ├─► Connects to Spark session
       ├─► Reads Unity Catalog table (e.g., titanic_fs)
       └─► Returns PySpark DataFrame

┌─────────────────────────────────────────────────────────────────┐
│ 4. PRE-TRAINING VALIDATION                                      │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► validate_trainer_config(trainer, spark_df)
       ├─► Check problem_type is valid
       ├─► Check label_col exists (for supervised)
       ├─► Validate pipeline has required methods
       ├─► Validate hyperparameter keys
       └─► Validate custom metrics are callable

┌─────────────────────────────────────────────────────────────────┐
│ 5. TRAINING PIPELINE                                            │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► _train_and_register(trainer, spark_df)
       │
       ├─► mlflow.start_run()
       │
       └─► trainer.train(spark_df)
           │
           ├─► Convert Spark DataFrame → Pandas
           ├─► preprocess(pdf) - drop columns, fillna
           ├─► Split X/y based on problem_type
           ├─► train_test_split (stratified for binary classification)
           │
           ├─► build_pipeline() via pipeline_factory
           │   └─► Returns Pipeline([("scaler", ...), ("clf", ...)])
           │
           ├─► IF param_grid exists:
           │   └─► GridSearchCV(pipeline, param_grid, cv=5, scoring=...)
           │       ├─► Classification: 'roc_auc' or 'accuracy'
           │       ├─► Regression: 'r2'
           │       └─► Clustering: custom silhouette scorer
           │
           ├─► Fit model (GridSearchCV or direct pipeline)
           │
           ├─► Capture all CV trials in self._grid_trials[]
           │   └─► Each trial: {params: {...}, metrics: {...}}
           │
           ├─► Evaluate on test set:
           │   ├─► Classification: accuracy, precision, recall, f1, auc
           │   ├─► Regression: rmse, mae, r2
           │   └─► Clustering: silhouette, davies_bouldin
           │
           └─► Return (model, metrics_dict, params_dict)

┌─────────────────────────────────────────────────────────────────┐
│ 6. MLFLOW TRACKING                                              │
└─────────────────────────────────────────────────────────────────┘
   │
   ├─► mlflow.log_params(params) - best hyperparameters
   ├─► mlflow.log_metrics(metrics) - test set performance
   │
   └─► mlflow.sklearn.log_model()
       ├─► Artifact path: "model"
       ├─► Infer signature from sample data
       ├─► Save input example (first 5 rows)
       └─► Register to Unity Catalog: sc["registry"]["uc_model_name"]

┌─────────────────────────────────────────────────────────────────┐
│ 7. MONITORING TABLE WRITES                                      │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► _write_monitoring_rows(result)
       │
       ├─► Create best model row:
       │   ├─► run_id, run_name, model_name, timestamp
       │   ├─► metrics: MAP<STRING,DOUBLE> (test set performance)
       │   └─► params: MAP<STRING,STRING> (best hyperparameters + metadata)
       │       ├─► __row_type = "best_holdout"
       │       ├─► __is_best = "1"
       │       └─► __feature_table = source table path
       │
       ├─► Create CV trial rows (one per GridSearch combination):
       │   ├─► run_id, run_name, model_name, timestamp
       │   ├─► metrics: MAP<STRING,DOUBLE> (CV mean/std/rank scores)
       │   └─► params: MAP<STRING,STRING> (trial hyperparameters)
       │       └─► __row_type = "cv_trial"
       │
       └─► Write all rows to monitoring table via Spark
           └─► Table: anl_drishti.test_mlops_monitoring.model_runs

┌─────────────────────────────────────────────────────────────────┐
│ 8. RESULT AGGREGATION                                           │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► Return result dictionary:
       {
           "run_id": "abc123...",
           "run_url": "https://databricks.../runs/abc123",
           "metrics": {"accuracy": 0.85, "f1": 0.82, ...},
           "params": {"clf__C": "1.0", "clf__penalty": "l2", ...},
           "trials": [
               {"params": {...}, "metrics": {"cv_mean_test_score": 0.83, ...}},
               ...
           ],
           "feature_table": "anl_drishti.test_mlops_features.titanic_fs"
       }

┌─────────────────────────────────────────────────────────────────┐
│ 9. SUMMARY OUTPUT                                               │
└─────────────────────────────────────────────────────────────────┘
   │
   └─► Print to console:
       ├─► Scenario name
       ├─► Task type
       ├─► Algorithm used
       ├─► MLflow run URL
       ├─► Best metrics
       └─► Best parameters
```

---

## Configuration System

### Scenario Selection Mechanism

**Environment Variable Control:**
```python
SCENARIO=classification python run_experiment.py   # Titanic
SCENARIO=regression python run_experiment.py       # Auto MPG
SCENARIO=clustering python run_experiment.py       # Iris
```

### Configuration Merging Logic

```python
# Step 1: Load YAML
cfg = yaml.safe_load(open("config.yaml"))

# Step 2: Extract defaults and scenario
defaults = cfg["defaults"]  # {registry_uri, monitoring_table, cv_folds, ...}
scenario_cfg = cfg["scenarios"][SCENARIO]  # Scenario-specific overrides

# Step 3: Merge (scenario takes precedence)
final_config = {**defaults, **scenario_cfg}

# Example for classification:
{
    "registry_uri": "databricks-uc",              # from defaults
    "monitoring_table": "anl...model_runs",       # from defaults
    "cv_folds": 5,                                # from defaults
    "random_state": 42,                           # from defaults
    "drop_cols": ["PassengerId"],                 # from defaults
    "feature_table": "anl...titanic_fs",          # from scenario
    "task_type": "classification",                # from scenario
    "label_col": "Survived",                      # from scenario
    "algorithm": "logreg",                        # from scenario
    "metrics": ["accuracy", "f1"],                # from scenario
    "param_grid": {"clf__C": [0.1, 1.0, 10.0]},   # from scenario
    "registry": {"uc_model_name": "...TitanicGeneric"}  # from scenario
}
```

### Parameter Grid Naming Convention

**Important:** Hyperparameters must use sklearn pipeline step naming:
```python
# Pipeline structure: Pipeline([("scaler", ...), ("clf", ...)])

# Correct parameter names:
param_grid = {
    "clf__C": [0.1, 1.0, 10.0],           # clf step, C parameter
    "clf__penalty": ["l2"],                # clf step, penalty parameter
    "clf__n_clusters": [2, 3, 4],         # clf step, n_clusters (KMeans)
}

# Invalid (will raise error):
param_grid = {
    "C": [0.1, 1.0],                      # Missing step prefix
    "estimator__C": [0.1, 1.0],           # Wrong step name
}
```

---

## Data Flow & Dependencies

### Input Data Requirements

**Unity Catalog Tables:**
1. **Classification:** `anl_drishti.test_mlops_features.titanic_fs`
   - Features: Pclass, Sex, Age, SibSp, Parch, Fare, Embarked, PassengerId
   - Label: Survived (binary: 0/1)

2. **Regression:** `anl_drishti.test_mlops_features.autompg_fs`
   - Features: cylinders, displacement, horsepower, weight, acceleration, model_year, origin
   - Label: mpg (continuous)

3. **Clustering:** `anl_drishti.test_mlops_features.iris_fs`
   - Features: sepal_length, sepal_width, petal_length, petal_width
   - Label: None (unsupervised)

### Output Data Products

**1. MLflow Artifacts:**
- Location: Databricks MLflow tracking server
- Contents:
  - Serialized sklearn model (pickle)
  - Model signature (input/output schema)
  - Input example (5 sample rows)
  - Parameters (logged)
  - Metrics (logged)

**2. Unity Catalog Model Registry:**
- Location: `anl_drishti.test_mlops_monitoring.<model_name>`
- Versions: Incrementing (v1, v2, v3, ...)
- Metadata: Linked to MLflow run

**3. Monitoring Table:**
- Location: `anl_drishti.test_mlops_monitoring.model_runs`
- Schema:
  ```
  run_id: STRING           - MLflow run identifier
  run_name: STRING         - Trainer class name
  model_name: STRING       - UC model registration path
  timestamp: STRING        - ISO 8601 timestamp
  metrics: MAP<STRING,DOUBLE>  - Performance metrics
  params: MAP<STRING,STRING>   - Hyperparameters + metadata
  ```
- Row Types:
  - Best holdout: `params["__row_type"] = "best_holdout"`
  - CV trials: `params["__row_type"] = "cv_trial"`

---

## Key Features

### 1. Multi-Problem-Type Support

**Automatic Adaptation:**
- **Classification:** Binary/multi-class, stratified splits, ROC-AUC/accuracy scoring
- **Regression:** Continuous targets, R2 scoring, RMSE/MAE metrics
- **Clustering:** Unsupervised, silhouette scoring, no train/test split

### 2. Hyperparameter Tuning

**GridSearchCV Integration:**
- Exhaustive search over parameter grid
- Cross-validation (5-fold default)
- Problem-type-specific scoring functions
- All trial results captured and logged

**Example Parameter Grids:**
```yaml
# Classification
param_grid:
  clf__C: [0.1, 1.0, 10.0]
  clf__penalty: [l2]
# → 3 combinations (3 * 1)

# Clustering
param_grid:
  clf__n_clusters: [2, 3, 4, 5, 6, 7, 8, 9, 10]
  clf__n_init: [10, 20]
  clf__random_state: [42]
# → 18 combinations (9 * 2 * 1)
```

### 3. Comprehensive Metric Tracking

**Built-in Metrics:**
- **Classification:** accuracy, precision, recall, f1, auc
- **Regression:** rmse, mae, r2
- **Clustering:** silhouette, davies_bouldin

**Custom Metrics (Extensible):**
```python
def metrics(self) -> Dict[str, Callable]:
    return {
        "custom_metric": lambda y_true, y_pred, X: custom_calculation(...)
    }
```

### 4. Model Signature Inference

**Automatic Schema Detection:**
```python
sample_X = preprocess(spark_df.sample(1000))
signature = infer_signature(sample_X, model.predict(sample_X))
# Captures input/output types for model serving
```

### 5. Validation System

**Pre-Training Checks:**
- Problem type validity
- Label column existence
- Pipeline method compatibility
- Hyperparameter key validity
- Custom metric callability

**Runtime Error Prevention:**
- Fails fast on configuration errors
- Clear error messages
- No wasted training time

### 6. Dynamic Trainer Loading

**Flexibility:**
```python
# Option 1: Dynamic import
runner = TrainerRunner(
    trainer_module="generic_trainer",
    trainer_class="GenericTrainer",
    ...
)

# Option 2: Pre-instantiated
trainer = CustomTrainer()
runner = TrainerRunner(trainer=trainer, ...)
```

---

## Monitoring & Tracking

### Monitoring Table Schema

**Table Name:** `anl_drishti.test_mlops_monitoring.model_runs`

**Columns:**
| Column       | Type                      | Description                          |
|--------------|---------------------------|--------------------------------------|
| run_id       | STRING                    | MLflow run UUID                      |
| run_name     | STRING                    | Trainer class name (e.g., GenericTrainer) |
| model_name   | STRING                    | Unity Catalog model path             |
| timestamp    | STRING                    | ISO 8601 run timestamp               |
| metrics      | MAP<STRING,DOUBLE>        | Performance metrics                  |
| params       | MAP<STRING,STRING>        | Hyperparameters + metadata           |

### Row Type Identification

**Best Model Row:**
```python
params = {
    "clf__C": "1.0",
    "clf__penalty": "l2",
    "__row_type": "best_holdout",      # Identifies as best model
    "__is_best": "1",                   # Flag for easy filtering
    "__feature_table": "anl...titanic_fs"  # Source data tracking
}
metrics = {
    "accuracy": 0.85,
    "f1": 0.82,
    "precision": 0.87,
    "recall": 0.78,
    "auc": 0.91
}
```

**CV Trial Row:**
```python
params = {
    "clf__C": "0.1",
    "clf__penalty": "l2",
    "__row_type": "cv_trial"           # Identifies as CV trial
}
metrics = {
    "cv_mean_test_score": 0.83,        # Mean CV score
    "cv_std_test_score": 0.02,         # Std CV score
    "cv_rank_test_score": 2.0          # Rank among trials
}
```

### Query Examples

**Find Best Models:**
```sql
SELECT 
    run_id, 
    model_name, 
    metrics['accuracy'] as accuracy,
    metrics['f1'] as f1
FROM anl_drishti.test_mlops_monitoring.model_runs
WHERE params['__is_best'] = '1'
ORDER BY timestamp DESC
```

**Analyze GridSearch Results:**
```sql
SELECT 
    run_id,
    params['clf__C'] as C_value,
    metrics['cv_mean_test_score'] as cv_score,
    metrics['cv_rank_test_score'] as rank
FROM anl_drishti.test_mlops_monitoring.model_runs
WHERE params['__row_type'] = 'cv_trial'
ORDER BY run_id, cv_score DESC
```

---

## Testing Strategy

### Unit Tests

**test_generic_trainer.py:**
- Tests GenericTrainer initialization
- Validates property mappings from config
- Verifies pipeline construction
- Checks parameter grid structure

**test_pipeline_factory.py:**
- Tests pipeline creation for known algorithms
- Validates pipeline structure (steps)
- Tests error handling for unknown algorithms

### Test Execution

```powershell
# Run all tests
pytest tests/

# Run specific test file
pytest tests/test_generic_trainer.py -v

# Run with coverage
pytest --cov=. --cov-report=html tests/
```

### Test Dependencies

**Fixtures:**
```python
@pytest.fixture
def fake_cfg():
    return {
        "task_type": "classification",
        "feature_table": "anl_drishti.test_mlops_features.titanic_fs",
        "label_col": "Survived",
        "algorithm": "logreg",
        "param_grid": {"clf__C": [1.0]},
        "drop_cols": ["PassengerId"],
    }
```

---

## Usage Examples

### Example 1: Classification (Titanic)

```bash
# Set scenario
export SCENARIO=classification

# Run training
python run_experiment.py
```

**Expected Output:**
```
📥 Reading features from table: anl_drishti.test_mlops_features.titanic_fs
📝 Run + 2 trial rows written to: anl_drishti.test_mlops_monitoring.model_runs

=== Run Summary ===
Scenario     : classification
Task Type    : classification
Algorithm    : logreg
MLflow URL   : https://databricks.../runs/abc123
Best Metrics : {'accuracy': 0.85, 'f1': 0.82, 'precision': 0.87, 'recall': 0.78, 'auc': 0.91}
Best Params  : {'clf__C': '1.0', 'clf__penalty': 'l2'}
```

### Example 2: Regression (Auto MPG)

```bash
export SCENARIO=regression
python run_experiment.py
```

**Expected Output:**
```
📥 Reading features from table: anl_drishti.test_mlops_features.autompg_fs
📝 Run + 0 trial rows written to: anl_drishti.test_mlops_monitoring.model_runs

=== Run Summary ===
Scenario     : regression
Task Type    : regression
Algorithm    : linreg
MLflow URL   : https://databricks.../runs/def456
Best Metrics : {'rmse': 3.2, 'mae': 2.5, 'r2': 0.82}
Best Params  : {}
```

### Example 3: Clustering (Iris)

```bash
export SCENARIO=clustering
python run_experiment.py
```

**Expected Output:**
```
📥 Reading features from table: anl_drishti.test_mlops_features.iris_fs
📝 Run + 17 trial rows written to: anl_drishti.test_mlops_monitoring.model_runs

=== Run Summary ===
Scenario     : clustering
Task Type    : clustering
Algorithm    : kmeans
MLflow URL   : https://databricks.../runs/ghi789
Best Metrics : {'silhouette': 0.55, 'davies_bouldin': 0.78}
Best Params  : {'clf__n_clusters': '3', 'clf__n_init': '10', 'clf__random_state': '42'}
```

### Example 4: Databricks Notebook

```python
# Cell 1: Configure
import os
os.environ["SCENARIO"] = "regression"

# Cell 2: Execute
import run_experiment
run_experiment.main()

# Cell 3: Query Results
spark.sql("""
    SELECT * 
    FROM anl_drishti.test_mlops_monitoring.model_runs 
    WHERE params['__is_best'] = '1'
    ORDER BY timestamp DESC 
    LIMIT 5
""").display()
```

---

## Extension Points

### Adding New Algorithms

**1. Update pipeline_factory.py:**
```python
from sklearn.svm import SVC

ESTIMATORS = {
    # ... existing ...
    "svm": SVC,  # Add new algorithm
}
```

**2. Update config.yaml:**
```yaml
scenarios:
  my_svm_classification:
    feature_table: anl_drishti.test_mlops_features.titanic_fs
    task_type: classification
    label_col: Survived
    algorithm: svm  # Use new algorithm key
    param_grid:
      clf__C: [0.1, 1.0, 10.0]
      clf__kernel: [linear, rbf]
```

**3. Run:**
```bash
export SCENARIO=my_svm_classification
python run_experiment.py
```

### Adding Custom Metrics

**Override in Trainer:**
```python
def metrics(self) -> Dict[str, Callable]:
    def custom_f2_score(y_true, y_pred, X):
        from sklearn.metrics import fbeta_score
        return fbeta_score(y_true, y_pred, beta=2)
    
    return {
        "f2_score": custom_f2_score
    }
```

### Adding Data Adapters

**Future Enhancement (adapters/ folder):**
```python
# adapters/csv_adapter.py
class CSVAdapter:
    def read(self, path: str) -> pd.DataFrame:
        return pd.read_csv(path)

# Update GenericTrainer to support file sources
if self.feature_table.endswith(".csv"):
    adapter = CSVAdapter()
    df = adapter.read(self.feature_table)
```

---

## Dependencies

**Core Requirements:**
```
pyspark>=3.0
mlflow>=2.0
scikit-learn>=1.0
pandas>=1.3
pyyaml>=5.4
pytest>=7.0  # for testing
```

**Databricks Environment:**
- Unity Catalog enabled
- MLflow tracking configured
- Spark session available
- Access to feature tables in `anl_drishti` catalog

---

## Troubleshooting

### Common Issues

**1. "SCENARIO not found in config.yaml"**
- **Cause:** Environment variable references non-existent scenario
- **Fix:** Check `SCENARIO` value matches key in `scenarios` section

**2. "Invalid hyperparameter(s)"**
- **Cause:** Parameter grid keys don't match pipeline parameters
- **Fix:** Use `clf__<param>` format; check with `pipeline.get_params()`

**3. "Label column not found"**
- **Cause:** Configured `label_col` doesn't exist in feature table
- **Fix:** Verify column name in Unity Catalog table

**4. "Failed to write to monitoring table"**
- **Cause:** Schema mismatch or table permissions
- **Fix:** Ensure table exists with correct schema; check write permissions

### Debug Mode

**Enable Debug Output:**
```python
# In run_experiment.py
print("\n[DEBUG] result returned from TrainerRunner:")
print("Params:", result.get("params"))
print("Metrics:", result.get("metrics"))
print("Trials (count):", len(result.get("trials", [])))
```

---

## Summary

This repository provides a **production-ready, extensible MLOps framework** with:

✅ **Multi-problem support** (classification/regression/clustering)  
✅ **Configuration-driven** (single YAML for all scenarios)  
✅ **Hyperparameter tuning** (GridSearchCV with full trial tracking)  
✅ **MLflow integration** (experiment tracking + model registry)  
✅ **Unity Catalog integration** (feature tables + model storage)  
✅ **Comprehensive monitoring** (detailed tracking tables)  
✅ **Validation system** (pre-training error prevention)  
✅ **Testing infrastructure** (pytest unit tests)  
✅ **Extensibility** (easy to add algorithms/metrics/data sources)

The architecture follows **SOLID principles** with clear separation of concerns:
- **BaseTrainer**: Contract definition
- **GenericTrainer**: Configuration implementation
- **TrainerRunner**: Orchestration logic
- **pipeline_factory**: Algorithm registry
- **config.yaml**: Behavior specification

All components are designed for **maintainability, testability, and scalability** in enterprise MLOps workflows.

---

**Last Updated:** November 27, 2025  
**Version:** 1.0  
**Status:** Production Ready
