import logging
logging.getLogger("threadpoolctl").setLevel(logging.ERROR)
import os, sys, yaml
from mlops_core import TrainerRunner


ALLOWED_METRICS = {
    "classification": {"accuracy","f1","precision","recall","roc_auc"},
    "regression": {"rmse","mae","r2"},
    "clustering": {"silhouette","davies_bouldin"},
}

def main():
    scenario = os.environ.get("SCENARIO", "classification")
    with open("config.yaml") as f:
        cfg = yaml.safe_load(f) or {}
    defaults = cfg.get("defaults", {})
    if "scenarios" not in cfg or scenario not in cfg["scenarios"]:
        print(f"ERROR: scenario '{scenario}' not found in config.yaml", file=sys.stderr)
        sys.exit(1)
    sc = {**defaults, **cfg["scenarios"][scenario]}

    # quick guardrail (doesn't affect core behavior)
    task = sc.get("task_type")
    metrics = sc.get("metrics", [])
    bad = [m for m in metrics if m not in ALLOWED_METRICS.get(task, set())]
    if bad:
        print(f"ERROR: invalid metrics for {task}: {bad}", file=sys.stderr)
        sys.exit(1)

    # MATCH your core: dynamic load GenericTrainer (no-arg __init__)
    runner = TrainerRunner(
        trainer_module="generic_trainer",
        trainer_class="GenericTrainer",
        register_model_name=sc["registry"]["uc_model_name"],
        register_stage=None,
        allow_stage_transition=False,
        # optional: if you later pass monitoring_table here, your core supports it
        # monitoring_table=sc.get("monitoring_table"),
    )

    # IMPORTANT: your core's run() takes NO args
    result = runner.run()

        # 🧩 Debug check: what we got back from runner
    print("\n[DEBUG] result returned from TrainerRunner:")
    print("Params:", result.get("params"))
    print("Metrics:", result.get("metrics"))
    print("Trials (count):", len(result.get("trials", [])))
    print("--------------------------------------------------")

    print("\n=== Run Summary ===")
    print("Scenario     :", scenario)
    print("Task Type    :", task)
    print("Algorithm    :", sc.get("algorithm"))
    print("MLflow URL   :", result.get("run_url"))
    print("Best Metrics :", result.get("metrics"))
    print("Best Params  :", result.get("params"))

if __name__ == "__main__":
    main()
 