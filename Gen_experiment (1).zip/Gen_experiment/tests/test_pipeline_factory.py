# tests/test_pipeline_factory.py
import pytest
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

from pipelines.pipeline_factory import build_pipeline

def test_build_logreg_pipeline():
    pipe = build_pipeline("logreg")
    assert isinstance(pipe, Pipeline)
    # last step should be the estimator named "clf"
    name, est = pipe.steps[-1]
    assert name == "clf"
    assert isinstance(est, LogisticRegression)

def test_unknown_algo_raises():
    with pytest.raises(ValueError):
        build_pipeline("does_not_exist")
