"""
mlops_core package initializer
------------------------------
Exposes the core training and orchestration classes for easy import:
    from mlops_core import BaseTrainer, TrainerRunner
"""

from .core import BaseTrainer, TrainerRunner, validate_trainer_config

__all__ = ["BaseTrainer", "TrainerRunner", "validate_trainer_config"]
