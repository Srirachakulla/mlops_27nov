from __future__ import annotations
import importlib
from typing import Any, Dict, Optional, Tuple, Callable

import mlflow
from mlflow.models import infer_signature
from mlflow.models.signature import ModelSignature
from mlflow.types import Schema, ColSpec, DataType
from mlflow.tracking import MlflowClient

from pyspark.sql import SparkSession
from pyspark.sql import types as T
from pyspark.sql import functions as F


# ==========================================================
# Base Trainer
# ==========================================================
class BaseTrainer:


    def __init__(self):
        # holder for all GridSearch combinations (filled after GridSearchCV.fit)
        self._grid_trials = []  # list[dict] with keys: "params", "metrics"


    # ---- REQUIRED ----
    @property
    def feature_table(self) -> str:
        raise NotImplementedError("Trainer must define `feature_table` (UC table path).")

    @property
    def problem_type(self) -> str:
        raise NotImplementedError("Trainer must define `problem_type`: classification, regression, clustering.")

    # ---- OPTIONAL ----
    @property
    def label_col(self) -> str:
        return "label"

    def preprocess(self, df):
        return df

    def build_pipeline(self):
        # default: StandardScaler + LogisticRegression (classification baseline)
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler
        from sklearn.linear_model import LogisticRegression
        return Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=200, solver="liblinear"))
        ])

    def param_grid(self) -> Dict[str, Any]:
        return {}

    def metrics(self) -> Dict[str, Callable]:
        
        return {}

    # ---- Default training routine ----
    def train(self, spark_df) -> Tuple[Any, Dict[str, Any], Dict[str, Any]]:
        import numpy as np
        from sklearn.model_selection import train_test_split, GridSearchCV
        from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, f1_score
        from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
        from sklearn.metrics import silhouette_score, davies_bouldin_score

        pdf = spark_df.toPandas()
        pdf = self.preprocess(pdf)

        # --- Split features/labels depending on problem_type ---
        if self.problem_type in ("classification", "regression"):
            if self.label_col not in pdf.columns:
                raise ValueError(f"Label column `{self.label_col}` not found in features.")
            X = pdf.drop(columns=[self.label_col])
            y = pdf[self.label_col]
        else:  # clustering
            X = pdf
            y = None

        # stratify only for binary classification
        strat = None
        if self.problem_type == "classification":
            try:
                strat = y if len(np.unique(y)) == 2 else None
            except Exception:
                strat = None

        if y is not None:
            X_tr, X_te, y_tr, y_te = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=strat
            )
        else:
            # clustering → no train/test split, just use all data
            X_tr, X_te, y_tr, y_te = X, X, None, None

        # --- Build estimator and validate param grid ---
        pipe = self.build_pipeline()
        grid = self.param_grid() or {}
        _validate_hyperparams(pipe, grid)

        if grid:
            scoring = None
            if self.problem_type == "classification":
                scoring = "roc_auc" if strat is not None else "accuracy"
            elif self.problem_type == "regression":
                scoring = "r2"
            elif self.problem_type == "clustering":
                # Use silhouette score to choose n_clusters
                from sklearn.metrics import silhouette_score
                def _silhouette_scorer(estimator, X, y=None):
                    try:
                        labels = (
                            estimator.predict(X)
                            if hasattr(estimator, "predict")
                            else estimator.fit_predict(X)
                        )
                        return float(silhouette_score(X, labels))
                    except Exception:
                        # If silhouette cannot be computed (e.g. single cluster), return a low score
                        return -1.0
                scoring = _silhouette_scorer


            from sklearn.model_selection import KFold

            cv_obj = 5
            if self.problem_type == "clustering":
                cv_obj = KFold(n_splits=5, shuffle=True, random_state=42) 

            search = GridSearchCV(pipe, grid, cv=cv_obj, scoring=scoring, n_jobs=-1)


            if y is not None:
                search.fit(X_tr, y_tr)
            else:
                search.fit(X_tr)
            model = search.best_estimator_
            used_params = {k: str(v) for k, v in (search.best_params_ or {}).items()}
                    
            # ---- Capture all GridSearch combinations into self._grid_trials ----
            self._grid_trials = []
            cv = getattr(search, "cv_results_", None)
            if isinstance(cv, dict) and "params" in cv:
                mean_key = "mean_test_score"
                std_key  = "std_test_score"
                rank_key = "rank_test_score"
                n = len(cv["params"])
                for i in range(n):
                    # params as strings (to fit map<string,string>)
                    trial_params = {str(k): str(v) for k, v in cv["params"][i].items()}

                    # metrics as doubles (to fit map<string,double>)
                    trial_metrics = {}
                    if mean_key in cv: trial_metrics["cv_mean_test_score"] = float(cv[mean_key][i])
                    if std_key  in cv: trial_metrics["cv_std_test_score"]  = float(cv[std_key][i])
                    if rank_key in cv: trial_metrics["cv_rank_test_score"] = float(cv[rank_key][i])

                    self._grid_trials.append({"params": trial_params, "metrics": trial_metrics})
            # --------------------------------------------------------------------


        else:
            if y is not None:
                model = pipe.fit(X_tr, y_tr)
            else:
                model = pipe.fit(X_tr)
            used_params = {k: str(v) for k, v in model.get_params(deep=False).items()}


        # --- Evaluate metrics ---
        metrics: Dict[str, Any] = {}
        custom_metrics = self.metrics()

        if self.problem_type == "classification" and y_te is not None:
            y_pred = model.predict(X_te)
            if hasattr(model, "predict_proba"):
                try:
                    proba = model.predict_proba(X_te)[:, 1]
                    metrics["auc"] = float(roc_auc_score(y_te, proba))
                except Exception:
                    pass
            metrics["accuracy"] = float(accuracy_score(y_te, y_pred))
            metrics["precision"] = float(precision_score(y_te, y_pred, zero_division=0))
            metrics["recall"] = float(recall_score(y_te, y_pred, zero_division=0))
            metrics["f1"] = float(f1_score(y_te, y_pred, zero_division=0))

        elif self.problem_type == "regression" and y_te is not None:
            y_pred = model.predict(X_te)
            metrics["rmse"] = float(mean_squared_error(y_te, y_pred, squared=False))
            metrics["mae"] = float(mean_absolute_error(y_te, y_pred))
            metrics["r2"] = float(r2_score(y_te, y_pred))

        elif self.problem_type == "clustering":
            labels = model.fit_predict(X_tr)
            try:
                metrics["silhouette"] = float(silhouette_score(X_tr, labels))
            except Exception:
                pass
            try:
                metrics["davies_bouldin"] = float(davies_bouldin_score(X_tr, labels))
            except Exception:
                pass

        # --- Apply developer custom metrics if defined ---
        if custom_metrics and y_te is not None:
            for name, fn in custom_metrics.items():
                try:
                    metrics[name] = float(fn(y_te, model.predict(X_te), X_te))
                except Exception as e:
                    raise ValueError(f"Custom metric '{name}' failed: {e}")

        return model, metrics, used_params


# ==========================================================
# Trainer Runner
# ==========================================================
class TrainerRunner:
    def __init__(self,
                 trainer_module: Optional[str] = None,
                 trainer_class: Optional[str] = None,
                 register_model_name: str = "",
                 register_stage: Optional[str] = None,
                 allow_stage_transition: bool = False,
                 trainer: Optional["BaseTrainer"] = None,          # NEW
                 monitoring_table: Optional[str] = None):          # NEW
        self.trainer_module = trainer_module
        self.trainer_class = trainer_class
        self.register_model_name = register_model_name
        self.register_stage = register_stage
        self.allow_stage_transition = allow_stage_transition
        self.trainer = trainer                                      # NEW
        self.monitoring_table = monitoring_table                    # NEW
        self.spark = SparkSession.builder.getOrCreate()

    def run(self) -> Dict[str, Any]:
        trainer = self._load_trainer()
        ft = getattr(trainer, "feature_table", None)
        if not ft:
            raise ValueError("Trainer must define `feature_table`.")

        sdf = self._read_feature_table(ft)

        # ✅ validate before training
        validate_trainer_config(trainer, sdf)

        result = self._train_and_register(trainer, sdf)
        self._write_monitoring_rows(result)
        return result
    

    def _train_and_register(self, trainer, spark_df) -> Dict[str, Any]:
        import mlflow
        import uuid
        import pandas as pd

        mlflow.set_registry_uri("databricks-uc")

        # Start MLflow run
        with mlflow.start_run() as run:
            model, metrics, params = trainer.train(spark_df)

            # Log params and metrics
            mlflow.log_params(params)
            mlflow.log_metrics(metrics)

            # Log model
            sample_df = spark_df.limit(1000).toPandas()
            sample_df = trainer.preprocess(sample_df)
            X_sample = sample_df.drop(columns=[trainer.label_col], errors="ignore")

            mlflow.sklearn.log_model(
                sk_model=model,
                artifact_path="model",
                signature=mlflow.models.infer_signature(X_sample, model.predict(X_sample)),
                input_example=X_sample.iloc[:5],
                registered_model_name=self.register_model_name if self.register_model_name else None
            )

            run_id = run.info.run_id
            run_url = f"{mlflow.get_tracking_uri()}/#/experiments/{mlflow.active_run().info.experiment_id}/runs/{run_id}"

            # NEW: collect all grid trials captured in BaseTrainer.train(...)
            trials = getattr(trainer, "_grid_trials", [])

            return {
                "run_id": run_id,
                "run_url": run_url,
                "metrics": metrics,   # best on holdout
                "params": params,     # best params
                "trials": trials,     # NEW: all GridSearch combinations (CV summary)
                "feature_table": trainer.feature_table  # ADD: for monitoring table
            }


    
    def _write_monitoring_rows(self, result: dict) -> None:
        

        """
        Write run + grid-trial rows into the monitoring table.
        Ensures 'metrics' is MAP<STRING,DOUBLE> and 'params' is MAP<STRING,STRING>.
        """
        from pyspark.sql import functions as F, types as T
        import datetime

        spark = self.spark

        # ▶️ use monitoring_table from config (required)
        target_tbl = self.monitoring_table
        if not target_tbl:
            raise ValueError("monitoring_table must be provided via config or TrainerRunner initialization")

        # ▶️ robust run_name (works with instance or dynamic loading)
        run_name = (
            self.trainer_class
            or getattr(getattr(self, "trainer", None), "__class__", type(None)).__name__
            or "UnknownTrainer"
        )

        # helpers to turn Python dicts into Spark MAPs (no pandas → avoids STRUCT inference)
        def _map_str_str(d: dict):
            items = []
            for k, v in (d or {}).items():
                items += [F.lit(str(k)), F.lit(str(v))]
            return F.create_map(*items) if items else F.create_map()

        def _map_str_double(d: dict):
            items = []
            for k, v in (d or {}).items():
                items += [F.lit(str(k)), F.lit(float(v))]
            return F.create_map(*items) if items else F.create_map()

        try:
            # ---------- BEST ROW ----------
            base_schema = T.StructType([
                T.StructField("run_id",     T.StringType(), True),
                T.StructField("run_name",   T.StringType(), True),
                T.StructField("model_name", T.StringType(), True),
                T.StructField("timestamp",  T.StringType(), True),
            ])

            
 
            # 🧩 Debug check: about to write to monitoring table

            print("\n[DEBUG] about to write best model row:")

            print("Params:", result.get("params"))

            print("Metrics:", result.get("metrics"))

            print("Trials (count):", len(result.get("trials", [])))

            print("Target Table:", self.monitoring_table or "default monitoring table")

            print("--------------------------------------------------")

 

            best_base = spark.createDataFrame(
                [(result.get("run_id"),
                run_name,
                self.register_model_name,
                datetime.datetime.utcnow().isoformat())],
                schema=base_schema
            )

            best_params = {k: str(v) for k, v in (result.get("params") or {}).items()}
            # handy flags inside params
            best_params["__row_type"] = "best_holdout"
            best_params["__is_best"]  = "1"
            best_params["__feature_table"] = result.get("feature_table", "unknown")  # ADD: feature table tracking

            best_df = (best_base
                    .withColumn("metrics", _map_str_double(result.get("metrics")))
                    .withColumn("params",  _map_str_str(best_params)))

            all_dfs = [best_df]

            # ---------- ALL GRID TRIALS ----------
            for trial in (result.get("trials") or []):
                trial_params  = dict(trial.get("params") or {})
                trial_params["__row_type"] = "cv_trial"

                trial_metrics = dict(trial.get("metrics") or {})

                trial_base = spark.createDataFrame(
                    [(result.get("run_id"),
                    run_name,
                    self.register_model_name,
                    datetime.datetime.utcnow().isoformat())],
                    schema=base_schema
                )

                trial_df = (trial_base
                            .withColumn("metrics", _map_str_double(trial_metrics))
                            .withColumn("params",  _map_str_str(trial_params)))
                all_dfs.append(trial_df)

            # ---------- UNION & ENFORCE FINAL SCHEMA ----------
            out_df = all_dfs[0]
            for extra in all_dfs[1:]:
                out_df = out_df.unionByName(extra)

            target_schema = T.StructType([
                T.StructField("run_id",     T.StringType(), True),
                T.StructField("run_name",   T.StringType(), True),
                T.StructField("model_name", T.StringType(), True),
                T.StructField("timestamp",  T.StringType(), True),
                T.StructField("metrics",    T.MapType(T.StringType(), T.DoubleType(), True), True),
                T.StructField("params",     T.MapType(T.StringType(), T.StringType(), True), True),
            ])
            out_df = out_df.select([F.col(f.name).cast(f.dataType) for f in target_schema.fields])

            # single append write (no mergeSchema)
            out_df.write.mode("append").saveAsTable(target_tbl)
            print(f"📝 Run + {len(all_dfs)-1} trial rows written to: {target_tbl}")

        except Exception as e:
            print(f"⚠️ Warning: Failed to write to monitoring table: {e}")
    

    def _load_trainer(self):
        if self.trainer is not None:
            return self.trainer
        module = importlib.import_module(self.trainer_module)
        klass = getattr(module, self.trainer_class)
        return klass()
 

    def _read_feature_table(self, table_name: str):
        print(f"📥 Reading features from table: {table_name}")
        return self.spark.table(table_name)



def validate_trainer_config(trainer: BaseTrainer, df) -> None:
    """Validates problem_type, label_col, pipeline compatibility, hyperparams, and metrics."""

    pt = getattr(trainer, "problem_type", None)
    if pt not in {"classification", "regression", "clustering"}:
        raise ValueError(f"Invalid problem_type '{pt}'. Must be classification, regression, or clustering.")

    # label_col validation
    cols = df.columns
    if pt in {"classification", "regression"}:
        if trainer.label_col not in cols:
            raise ValueError(f"Label column '{trainer.label_col}' not found in feature table.")
    elif pt == "clustering" and hasattr(trainer, "label_col"):
        # shouldn't require label for clustering
        pass

    # pipeline compatibility
    est = trainer.build_pipeline()
    if pt == "classification" and not hasattr(est, "predict"):
        raise ValueError("Classification pipeline must implement predict().")
    if pt == "regression" and not hasattr(est, "predict"):
        raise ValueError("Regression pipeline must implement predict().")
    if pt == "clustering" and not (hasattr(est, "fit_predict") or hasattr(est, "predict")):
        raise ValueError("Clustering pipeline must implement fit_predict() or predict().")

    # hyperparameters already validated in train()
    _validate_hyperparams(est, trainer.param_grid())

    # metrics validation if custom
    if trainer.metrics():
        if not isinstance(trainer.metrics(), dict):
            raise ValueError("metrics() must return a dict {name: function}.")
        for name, fn in trainer.metrics().items():
            if not callable(fn):
                raise ValueError(f"Metric '{name}' is not callable.")


def _validate_hyperparams(estimator, grid: Dict[str, Any]) -> None:
    valid_params = set(estimator.get_params().keys())
    invalid = [k for k in grid.keys() if k not in valid_params]
    if invalid:
        raise ValueError(f"Invalid hyperparameter(s): {invalid}. Valid keys: {sorted(valid_params)[:15]} ...")


def _to_float_or_none(x: Any) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None

def _coerce_pandas_for_signature(df):
    import pandas as pd
    out = df.copy()
    for c in out.columns:
        if pd.api.types.is_object_dtype(out[c].dtype):
            out[c] = out[c].astype(str)
        if str(out[c].dtype).startswith("datetime64"):
            out[c] = out[c].astype("datetime64[ns]")
    return out

def _fallback_signature(sample_X):
    inputs = []
    for col, dtype in sample_X.dtypes.items():
        mlflow_dtype = _pd_dtype_to_mlflow(dtype)
        inputs.append(ColSpec(mlflow_dtype, name=str(col)))
    in_schema = Schema(inputs)
    out_schema = Schema([ColSpec(DataType.double, name="prediction")])
    return ModelSignature(inputs=in_schema, outputs=out_schema)

def _pd_dtype_to_mlflow(dtype) -> DataType:
    s = str(dtype)
    if s.startswith("int"):       return DataType.long
    if s.startswith("float"):     return DataType.double
    if s == "bool":               return DataType.boolean
    if s.startswith("datetime"):  return DataType.datetime
    return DataType.string

def _safe_predict(model, X):
    try:
        return model.predict(X)
    except Exception:
        if hasattr(model, "predict_proba"):
            import numpy as np
            return model.predict_proba(X)[:, -1].astype(float)
        raise
