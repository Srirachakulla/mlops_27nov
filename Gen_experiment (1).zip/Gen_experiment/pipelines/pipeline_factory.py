"""
Pipeline Factory
----------------
Central place to define which ML algorithms are available
and how their sklearn Pipelines are built.
"""

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.cluster import KMeans

# Mapping: short algorithm key → sklearn estimator
ESTIMATORS = {
    # Classification
    "logreg": LogisticRegression,
    "rf_cls": RandomForestClassifier,

    # Regression
    "linreg": LinearRegression,
    "rf_reg": RandomForestRegressor,

    # Clustering
    "kmeans": KMeans,
}


def build_pipeline(algo_key: str):
    """
    Build and return an sklearn Pipeline for the given algorithm key.
    """
    if algo_key not in ESTIMATORS:
        raise ValueError(
            f"Unknown algorithm key '{algo_key}'. "
            f"Available: {', '.join(sorted(ESTIMATORS.keys()))}"
        )

    EstimatorClass = ESTIMATORS[algo_key]

    # Use mean-centering for KMeans; keep with_mean=False elsewhere
    from sklearn.preprocessing import StandardScaler
    if algo_key == "kmeans":
        scaler = StandardScaler(with_mean=True)
    else:
        scaler = StandardScaler(with_mean=False)

    pipeline = Pipeline([
        ("scaler", scaler),
        ("clf", EstimatorClass())
    ])
    return pipeline
    return pipeline
