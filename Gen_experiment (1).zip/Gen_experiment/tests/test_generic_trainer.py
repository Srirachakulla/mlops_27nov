import pytest
from generic_trainer import GenericTrainer

# a small fake config that mirrors your Titanic classification setup
@pytest.fixture
def fake_cfg():
    return {
        "task_type": "classification",
        "feature_table": "anl_drishti.test_mlops_features.titanic_fs",
        "label_col": "Survived",
        "algorithm": "logreg",
        "param_grid": {"clf__C": [1.0]},
        "drop_cols": ["PassengerId"],
    }

def test_generic_trainer_init(fake_cfg):
    trainer = GenericTrainer(fake_cfg)
    assert trainer.problem_type == "classification"
    assert trainer.feature_table.endswith("titanic_fs")
    assert trainer.label_col == "Survived"

def test_build_pipeline(fake_cfg):
    trainer = GenericTrainer(fake_cfg)
    pipe = trainer.build_pipeline()
    assert "clf" in dict(pipe.steps)
    # ensures correct estimator type
    from sklearn.linear_model import LogisticRegression
    assert isinstance(pipe.named_steps["clf"], LogisticRegression)

def test_param_grid(fake_cfg):
    trainer = GenericTrainer(fake_cfg)
    grid = trainer.param_grid()
    assert "clf__C" in grid
    assert isinstance(grid["clf__C"], list)
