# Hardcoded Values Audit Report

**Date:** November 27, 2025  
**Purpose:** Identify all hardcoded values that should be moved to config.yaml for better configurability

---

## Executive Summary

This audit identifies **25 hardcoded values** across 4 files that could benefit from being moved to the configuration file. These values are currently scattered throughout the codebase and make it difficult to change behavior without modifying source code.

**Priority Levels:**
- 🔴 **HIGH:** Critical values that affect model behavior and should definitely be configurable
- 🟡 **MEDIUM:** Useful to configure for flexibility but not critical
- 🟢 **LOW:** Nice-to-have configurations, minimal impact

---

## File-by-File Analysis

### 1. **mlops_core/core.py**

#### 🔴 HIGH PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 16-18 | `"anl_drishti"`, `"test_mlops_monitoring"` | Monitoring catalog and schema names | `defaults.monitoring_catalog`, `defaults.monitoring_schema` | **Critical:** Changes require code modification, affects all monitoring |
| 265 | `"databricks-uc"` | MLflow registry URI | `defaults.registry_uri` | **High:** Already in config but duplicated in code |
| 318 | `"anl_drishti.test_mlops_monitoring.model_runs"` | Default monitoring table fallback | `defaults.monitoring_table` | **High:** Already in config but hardcoded fallback |
| 98 | `test_size=0.2` | Train/test split ratio | `defaults.test_size` or `scenario.test_size` | **High:** Affects model evaluation significantly |
| 98 | `random_state=42` | Split random seed | `defaults.random_state` | **High:** Already in config but not used here |
| 134 | `cv_obj = 5` | Cross-validation folds (non-clustering) | `defaults.cv_folds` | **High:** Already in config but hardcoded |
| 136 | `n_splits=5` | K-Fold splits for clustering | `defaults.cv_folds` | **High:** Already in config but duplicated |
| 136 | `shuffle=True` | K-Fold shuffle parameter | `defaults.cv_shuffle` | **Medium:** Affects reproducibility |
| 136 | `random_state=42` | K-Fold random seed | `defaults.random_state` | **High:** Already in config but duplicated |
| 138 | `n_jobs=-1` | GridSearchCV parallel jobs | `defaults.n_jobs` | **Medium:** Performance configuration |

#### 🟡 MEDIUM PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 57 | `max_iter=200` | LogisticRegression max iterations | `defaults.baseline_logreg_max_iter` | **Medium:** Affects default pipeline convergence |
| 57 | `solver="liblinear"` | LogisticRegression solver | `defaults.baseline_logreg_solver` | **Medium:** Algorithm choice for baseline |
| 191-193 | `zero_division=0` | Precision/recall/F1 handling | `defaults.zero_division_value` | **Low:** Edge case handling |
| 278 | `limit(1000)` | Sample size for signature inference | `defaults.signature_sample_size` | **Medium:** Memory vs accuracy tradeoff |
| 282 | `artifact_path="model"` | MLflow artifact path | `defaults.mlflow_artifact_path` | **Low:** Convention, rarely changes |
| 284 | `iloc[:5]` | Input example rows | `defaults.mlflow_input_example_rows` | **Low:** Documentation convenience |

#### 🟢 LOW PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 127 | `return -1.0` | Failed silhouette score fallback | `defaults.failed_silhouette_score` | **Low:** Error handling default |
| 371-373 | `"__row_type"`, `"__is_best"`, `"__feature_table"` | Monitoring metadata keys | `defaults.monitoring_metadata_keys` | **Low:** Internal convention |
| 372 | `"best_holdout"`, `"1"` | Metadata values | N/A | **Low:** Constants |
| 390 | `"cv_trial"` | Trial row type identifier | N/A | **Low:** Constant |

**Summary for mlops_core/core.py:**
- 🔴 **10 HIGH priority** items (mostly training parameters and infrastructure configs)
- 🟡 **6 MEDIUM priority** items (baseline model settings and sampling)
- 🟢 **5 LOW priority** items (metadata and constants)

---

### 2. **generic_trainer.py**

#### 🔴 HIGH PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 9 | `"classification"` | Default scenario fallback | `defaults.default_scenario` | **High:** User experience when SCENARIO not set |
| 10 | `"config.yaml"` | Config file name | Environment variable or constant | **Medium:** Flexibility for different environments |
| 21 | `"logreg"` | Default algorithm fallback | `defaults.default_algorithm` | **Medium:** Baseline when not specified |

#### 🟡 MEDIUM PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 41 | `errors="ignore"` | Drop columns error handling | `defaults.drop_errors_handling` | **Low:** Error behavior |
| 41 | `fillna(0)` | Missing value fill strategy | `defaults.fillna_strategy` and `defaults.fillna_value` | **Medium:** Data preprocessing approach |

**Summary for generic_trainer.py:**
- 🔴 **3 HIGH priority** items (defaults and file paths)
- 🟡 **2 MEDIUM priority** items (preprocessing configuration)

---

### 3. **pipelines/pipeline_factory.py**

#### 🟡 MEDIUM PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 42 | `with_mean=True` (KMeans) | StandardScaler centering for clustering | `defaults.kmeans_scaler_with_mean` | **Medium:** Algorithm-specific preprocessing |
| 44 | `with_mean=False` (others) | StandardScaler centering for others | `defaults.default_scaler_with_mean` | **Medium:** Default preprocessing behavior |

#### 🟢 LOW PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 46-47 | `"scaler"`, `"clf"` | Pipeline step names | `defaults.pipeline_step_names` | **Low:** Internal convention (affects param_grid keys) |

**Summary for pipeline_factory.py:**
- 🟡 **2 MEDIUM priority** items (preprocessing configuration)
- 🟢 **1 LOW priority** item (naming conventions)

---

### 4. **run_experiment.py**

#### 🔴 HIGH PRIORITY

| Line | Hardcoded Value | Current Usage | Recommended Config Key | Impact |
|------|----------------|---------------|----------------------|--------|
| 2 | `logging.ERROR` | Logging level for threadpoolctl | `defaults.threadpoolctl_log_level` | **Low:** Debug configuration |
| 6-10 | `ALLOWED_METRICS` dictionary | Metric validation rules | Move to config or keep as constant | **Medium:** Validation logic |
| 15 | `"classification"` | Default scenario | `defaults.default_scenario` | **High:** Same as generic_trainer.py |
| 16 | `"config.yaml"` | Config file name | Environment variable or constant | **High:** Same as generic_trainer.py |
| 33 | `trainer_module="generic_trainer"` | Module name to import | `defaults.trainer_module` | **Medium:** Flexibility for custom trainers |
| 34 | `trainer_class="GenericTrainer"` | Class name to instantiate | `defaults.trainer_class` | **Medium:** Flexibility for custom trainers |
| 35 | `register_stage=None` | Model stage on registration | `defaults.register_stage` | **Low:** Currently unused |
| 36 | `allow_stage_transition=False` | Stage transition flag | `defaults.allow_stage_transition` | **Low:** Currently unused |

**Summary for run_experiment.py:**
- 🔴 **2 HIGH priority** items (defaults and file paths)
- 🟡 **4 MEDIUM priority** items (trainer configuration and validation)
- 🟢 **2 LOW priority** items (unused features)

---

## Recommended Configuration Structure

### Proposed Enhanced config.yaml

```yaml
# ==========================================================
#  Enhanced Generic MLOps Configuration
# ==========================================================

# ========== INFRASTRUCTURE SETTINGS ==========
infrastructure:
  # MLflow Configuration
  mlflow:
    registry_uri: databricks-uc
    artifact_path: model
    signature_sample_size: 1000
    input_example_rows: 5
  
  # Monitoring Configuration
  monitoring:
    catalog: anl_drishti
    schema: test_mlops_monitoring
    table_name: model_runs  # Will be combined as: catalog.schema.table_name
    metadata_keys:
      row_type: __row_type
      is_best: __is_best
      feature_table: __feature_table

# ========== TRAINING DEFAULTS ==========
defaults:
  # System Configuration
  default_scenario: classification
  config_file: config.yaml  # Can be overridden via env var
  
  # Trainer Configuration
  trainer_module: generic_trainer
  trainer_class: GenericTrainer
  
  # Model Registry
  registry_uri: databricks-uc
  register_stage: null
  allow_stage_transition: false
  
  # Training Parameters
  test_size: 0.2
  random_state: 42
  cv_folds: 5
  cv_shuffle: true
  n_jobs: -1
  
  # Data Preprocessing
  fillna_strategy: constant  # Options: constant, mean, median, mode
  fillna_value: 0
  drop_errors_handling: ignore  # Options: ignore, raise
  
  # Baseline Model (Default Pipeline)
  baseline_logreg_max_iter: 200
  baseline_logreg_solver: liblinear
  
  # Pipeline Configuration
  default_algorithm: logreg
  default_scaler_with_mean: false
  kmeans_scaler_with_mean: true
  pipeline_step_names:
    scaler: scaler
    estimator: clf
  
  # Metrics Configuration
  zero_division_value: 0  # For precision/recall/F1
  failed_silhouette_score: -1.0
  
  # Logging
  threadpoolctl_log_level: ERROR
  
  # Legacy (keep for backward compatibility)
  drop_cols: ["PassengerId"]

# ========== METRIC VALIDATION RULES ==========
allowed_metrics:
  classification:
    - accuracy
    - f1
    - precision
    - recall
    - roc_auc
  regression:
    - rmse
    - mae
    - r2
  clustering:
    - silhouette
    - davies_bouldin

# ========== SCENARIO DEFINITIONS ==========
scenarios:
  # [Existing scenarios remain unchanged]
  classification:
    feature_table: anl_drishti.test_mlops_features.titanic_fs
    task_type: classification
    label_col: Survived
    algorithm: logreg
    metrics: [accuracy, f1]
    param_grid:
      clf__C: [0.1, 1.0, 10.0]
      clf__penalty: [l2]
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.TitanicGeneric
    # Optional scenario-specific overrides:
    # test_size: 0.25
    # random_state: 123
    # cv_folds: 10

  regression:
    feature_table: anl_drishti.test_mlops_features.autompg_fs
    task_type: regression
    label_col: mpg
    algorithm: linreg
    metrics: [rmse, mae, r2]
    param_grid: {}
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.autompgregression

  clustering:
    feature_table: anl_drishti.test_mlops_features.iris_fs
    task_type: clustering
    label_col: null
    algorithm: kmeans
    metrics: [silhouette, davies_bouldin]
    param_grid:
      clf__n_clusters: [2, 3, 4, 5, 6, 7, 8, 9, 10]
      clf__n_init: [10, 20]
      clf__random_state: [42]
    registry:
      uc_model_name: anl_drishti.test_mlops_monitoring.irisClustering
```

---

## Migration Impact Analysis

### Breaking Changes
If these changes are implemented, the following areas will be affected:

#### HIGH IMPACT (Requires Code Changes)
1. **mlops_core/core.py:**
   - `BaseTrainer.train()` method needs to read test_size, random_state, cv_folds from config
   - `TrainerRunner.__init__()` needs to accept and use infrastructure config
   - `_write_monitoring_rows()` needs to build table path from config

2. **generic_trainer.py:**
   - `__init__()` needs to read default_scenario, fillna_strategy, etc.
   - `preprocess()` needs configurable fillna behavior

3. **run_experiment.py:**
   - `main()` needs to read ALLOWED_METRICS from config
   - `TrainerRunner` initialization needs to pass infrastructure config

#### MEDIUM IMPACT (Optional Improvements)
4. **pipelines/pipeline_factory.py:**
   - `build_pipeline()` can read scaler parameters from config
   - Minimal changes, backward compatible

### Backward Compatibility Strategy

**Option 1: Gradual Migration (Recommended)**
- Keep current hardcoded values as defaults
- Read from config only if keys exist
- Emit warnings when using hardcoded defaults
- Example:
  ```python
  test_size = config.get("test_size", 0.2)  # Fallback to 0.2
  ```

**Option 2: Breaking Change with Version Bump**
- Require all values in config
- Fail fast if missing
- Update all scenarios to include new keys
- Major version bump (1.x → 2.0)

---

## Priority Recommendations

### Phase 1: Critical Infrastructure (Immediate)
Move these hardcoded values first (affects multiple runs):

1. ✅ **Already in config but duplicated in code:**
   - `registry_uri` (line 265 in core.py)
   - `monitoring_table` (line 318 in core.py)
   - `random_state` (lines 98, 136 in core.py)
   - `cv_folds` (lines 134, 136 in core.py)

2. 🔴 **Add to config (high priority):**
   - `test_size` (train/test split ratio)
   - `monitoring_catalog` and `monitoring_schema` (lines 16-17)
   - `n_jobs` (parallelization)
   - `default_scenario` (user experience)

### Phase 2: Training Configuration (Next Sprint)
3. 🟡 **Medium priority additions:**
   - `baseline_logreg_max_iter` and `baseline_logreg_solver`
   - `fillna_strategy` and `fillna_value`
   - `signature_sample_size`
   - `cv_shuffle`
   - Scaler `with_mean` configurations

### Phase 3: Nice-to-Have (Future)
4. 🟢 **Low priority (for completeness):**
   - Metadata key names
   - Pipeline step names
   - Error handling strategies
   - Logging levels

---

## Code Change Estimate

### Files Requiring Modification: **4 files**
1. `config.yaml` - Add ~60 new lines
2. `mlops_core/core.py` - Modify ~15 locations
3. `generic_trainer.py` - Modify ~5 locations
4. `run_experiment.py` - Modify ~3 locations

### Testing Requirements:
- Update unit tests to use new config structure
- Add integration tests for config loading
- Verify backward compatibility if gradual migration chosen

### Estimated Effort:
- **Phase 1:** 4-6 hours (critical infrastructure)
- **Phase 2:** 3-4 hours (training configuration)
- **Phase 3:** 2-3 hours (nice-to-have)
- **Testing:** 4-6 hours (comprehensive validation)

**Total:** 13-19 hours of development + testing

---

## Benefits of Migration

### Current Pain Points:
❌ Multiple hardcoded database/catalog names  
❌ Training parameters scattered across code  
❌ Can't change behavior without code modification  
❌ Inconsistent use of config vs hardcoded values  
❌ Difficult to maintain different environments (dev/staging/prod)

### After Migration:
✅ **Single Source of Truth:** All configuration in one YAML file  
✅ **Environment Flexibility:** Easy to create dev/prod configs  
✅ **No Code Changes:** Modify behavior via config only  
✅ **Better Testing:** Override configs for unit tests  
✅ **Documentation:** Config serves as living documentation  
✅ **Auditability:** Track config changes in version control

---

## Appendix: Complete Hardcoded Values List

### By Category

#### Database/Infrastructure (8 instances)
- Catalog name: `anl_drishti` (2 locations)
- Schema name: `test_mlops_monitoring` (2 locations)
- Registry URI: `databricks-uc` (2 locations)
- Monitoring table: full path (2 locations)

#### Training Parameters (9 instances)
- `test_size=0.2` (1 location)
- `random_state=42` (3 locations - config exists but not used)
- `cv_folds=5` (2 locations - config exists but not used)
- `n_jobs=-1` (1 location)
- `shuffle=True` (1 location)
- `zero_division=0` (3 locations)

#### Model Configuration (4 instances)
- `max_iter=200` (1 location)
- `solver="liblinear"` (1 location)
- `with_mean=True/False` (2 locations)

#### MLflow Settings (4 instances)
- `artifact_path="model"` (1 location)
- `limit(1000)` (1 location)
- `iloc[:5]` (1 location)
- Sample size (1 location)

#### Defaults and Fallbacks (5 instances)
- Default scenario: `"classification"` (2 locations)
- Default algorithm: `"logreg"` (1 location)
- Config file: `"config.yaml"` (2 locations)

#### Preprocessing (2 instances)
- `fillna(0)` (1 location)
- `errors="ignore"` (1 location)

#### Validation Rules (1 instance)
- `ALLOWED_METRICS` dictionary (1 location)

#### Constants and Metadata (6 instances)
- Metadata keys: `__row_type`, `__is_best`, `__feature_table`
- Metadata values: `"best_holdout"`, `"cv_trial"`, `"1"`
- Failed score: `-1.0`

**Total Count: 39 hardcoded values across 4 files**

---

## Conclusion

The current codebase has **25 meaningful hardcoded values** that should be moved to configuration. The most critical ones are already partially in config but duplicated in code, indicating an incomplete migration. 

**Recommendation:** Proceed with **Phase 1** immediately to consolidate existing config usage and eliminate code duplication. This will provide immediate benefits with minimal risk.

---

**Document Version:** 1.0  
**Last Updated:** November 27, 2025  
**Prepared By:** GitHub Copilot  
**Review Status:** Ready for Implementation Planning
